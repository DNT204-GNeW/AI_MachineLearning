
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
# Tạo tập dữ liệu mẫu
X, y = datasets.make_classification(n_samples=100, n_features=2,
n_redundant=0, random_state=42)
# Chia tập dữ liệu thành tập huấn luyện và tập kiểm tra
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3,
random_state=42)
# Chuẩn hóa dữ liệu
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
# Huấn luyện mô hình SVM
svm = SVC(kernel='linear', C=1.0)
svm.fit(X_train_scaled, y_train)
# Dự đoán nhãn cho tập kiểm tra
y_pred = svm.predict(X_test_scaled)
# Tính độ chính xác
accuracy = accuracy_score(y_test, y_pred)
print("Độ chính xác:", accuracy)
# Vẽ biểu đồ kết quả
plt.scatter(X_test_scaled[:, 0], X_test_scaled[:, 1], c=y_test,
cmap=plt.cm.Paired)
# Vẽ siêu phẳng phân tách
w = svm.coef_[0]
b = svm.intercept_[0]
x_min, x_max = X_test_scaled[:, 0].min() - 1, X_test_scaled[:, 0].max() + 1
y_min, y_max = (-w[0] * x_min - b) / w[1], (-w[0] * x_max - b) / w[1]
plt.plot([x_min, x_max], [y_min, y_max], 'k-')
plt.xlabel('Nhan 1')
plt.ylabel('Nhan 2')
plt.title('SVM Classification')
plt.show()
